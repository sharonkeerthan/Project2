Origin: https://github.com/google/flatbuffers/tree/v23.1.21
